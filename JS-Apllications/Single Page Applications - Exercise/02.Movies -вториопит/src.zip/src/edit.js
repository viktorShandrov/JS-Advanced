const editSection = document.querySelector("#edit-movie");



export{
    editSection
}
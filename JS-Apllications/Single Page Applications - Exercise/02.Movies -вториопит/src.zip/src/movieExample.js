const exampleSection = document.querySelector("#movie-example");




export{
    exampleSection
}
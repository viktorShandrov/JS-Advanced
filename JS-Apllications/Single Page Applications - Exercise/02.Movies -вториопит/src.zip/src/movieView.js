const movieSection = document.querySelector("#movie");


export{
    movieSection
}
export function getMainSection(){
    return document.querySelector("main");
}